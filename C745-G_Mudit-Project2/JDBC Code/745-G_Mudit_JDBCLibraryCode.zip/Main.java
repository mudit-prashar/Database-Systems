import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.IOException;
import java.sql.*;


public class Main extends Application {

    private static String connectionUrl;
    public static ResultSet queryResults;
    static FXMLLoader loader;
    Parent root;

    @Override
    public void start(Stage primaryStage) throws Exception{
        loader = new FXMLLoader(getClass().getResource("JDBCGUI.fxml"));
        root = loader.load();

        primaryStage.setTitle("JDBC GUI");
        primaryStage.setScene(new Scene(root, 991, 623));
        primaryStage.show();
        Controller controller = new Controller(loader,root);
    }


    public static void main(String[] args) throws ClassNotFoundException, IOException {
        connect();
        launch(args);
    }

    public static void connect() throws ClassNotFoundException {
        // Create a variable for the connection string.
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        connectionUrl =
                "jdbc:sqlserver://localhost:1433;"
                        + "database=AdventureWorks2014;"
                        + "user=jbdc;"
                        + "password=123123;"
                        + "trustServerCertificate=false;"
                        + "loginTimeout=30;";

        try (Connection con = DriverManager.getConnection(connectionUrl);) {
            System.out.println("Connection Successful");
        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            System.out.println("Connection Failed");
            e.printStackTrace();
        }
    }


    public static void executeRawSQL(String selectedDB, String text) throws SQLException {

        ObservableList<ObservableList> data = FXCollections.observableArrayList();

        try (Connection connection = DriverManager.getConnection(connectionUrl);) {
            ResultSet resultSet = null;
            Statement statement = connection.createStatement();
            String selectSql = "USE ["+selectedDB+"]; "+text;

            resultSet = statement.executeQuery(selectSql);

            TableView queryResults = (TableView)loader.getNamespace().get("resultTableView");


            for(int i=0 ; i<resultSet.getMetaData().getColumnCount(); i++){
                final int j = i;
                TableColumn col = new TableColumn(resultSet.getMetaData().getColumnName(i+1));
                col.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ObservableList,String>,ObservableValue<String>>(){
                    public ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableList, String> param) {
                        return new SimpleStringProperty(param.getValue().get(j).toString());
                    }
                });
                queryResults.getColumns().addAll(col);
                System.out.println("Column ["+i+"] ");
            }


            while(resultSet.next()){
                //Iterate Row
                ObservableList<String> row = FXCollections.observableArrayList();
                for(int i=1 ; i<=resultSet.getMetaData().getColumnCount(); i++){
                    //Iterate Column
                    row.add(resultSet.getString(i));
                }
                System.out.println("Row [1] added "+row );
                data.add(row);
            }
            queryResults.setItems(data);
        } catch (SQLException e) {
            System.out.println("Connection Failed");
            e.printStackTrace();
        }
    }

}
