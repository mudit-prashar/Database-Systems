Description:
This is a JavaFX GUI application that accepts queries and gives you the results. The connection to the database is done using the 
Microsoft JDBC Driver so you may need to add that library as a dependency for this to work properly
Author: Thomas Jimenez