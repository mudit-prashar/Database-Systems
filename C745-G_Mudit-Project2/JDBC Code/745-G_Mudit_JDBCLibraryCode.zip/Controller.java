package sample;

import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import java.io.IOException;
import java.sql.SQLException;

public class Controller {
    FXMLLoader loader;
    Parent root;

    public Controller(FXMLLoader load,Parent controller) throws IOException {
        loader = load;
        root = controller;
        System.out.println("Controller Established");
        eventHandlers();
        changeStatus();
        addDatabaseOptions();

    }

    public void changeStatus(){
        System.out.println("Changing Database Connection Status");
        Text dbStatus = (Text)loader.getNamespace().get("dbConnectionStatus");
        dbStatus.setText("Connection Status: Connected");
        dbStatus.setFill(Color.GREEN);
    }

    public void addDatabaseOptions(){
        ComboBox databaseOptions = (ComboBox)loader.getNamespace().get("databaseOptions");
        databaseOptions.getItems().addAll(
                "AdventureWorks2014",
                "AdventureWorksDW2016",
                "NORTHWINDS2019TSQLV5",
                "WideWorldImporters",
                "WideWorldImportersDW");
        System.out.println("Added Database Options");
    }

    public void eventHandlers(){
        Button executeSQL = (Button)loader.getNamespace().get("executeQuery");
        executeSQL.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                ComboBox databaseOptions = (ComboBox)loader.getNamespace().get("databaseOptions");
                String selectedDB = (String) databaseOptions.getValue();
                TextArea sql = (TextArea)loader.getNamespace().get("rawQueryTextbox");
                String query = sql.getText();
                try {
                    Main.executeRawSQL(selectedDB, query);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
